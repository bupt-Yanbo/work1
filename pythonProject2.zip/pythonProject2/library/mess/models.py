from django.db import models

# Create your models here.
class message(models.Model):
    name = models.CharField(max_length=32)
    money =models.CharField(max_length=32)
    time = models.IntegerField()