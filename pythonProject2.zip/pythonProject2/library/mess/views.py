from django.shortcuts import render
from django.http import HttpResponseRedirect

# Create your views here.
# from django.db import  models
from mess import models
from django.shortcuts import  HttpResponse
def db_handle(request):
    # mess_list_obj=models.message.objects.all()
    # add(request)
    return render(request,'first0.html')
    # return render(request,'t1.html',{'li':mess_list_obj})

    # return HttpResponse('ok')

def login_success(request):
    return render(request,'first1.html')

def logout_success(request):
    return render(request,'first0.html')

def shop_car(request):
    mess_list_obj = models.message.objects.all()
    return render(request,'new_car.html',{'li':mess_list_obj})

def add (request):
    if request.method == "POST":
        print(request.POST['name'],request.POST['money'])
        models.message.objects.create(name=request.POST['name'],
                                      money=request.POST['money'],
                                      time=request.POST['time'])
        mess_list_obj = models.message.objects.all()
    return render(request,'new_car.html',{'li':mess_list_obj})

def add_book (request):
    if request.method == "POST":
        # print(request.POST['name'],request.POST['money'])
        money=59
        ex_price=59
        if len(request.POST['name'])<1:
            return render(request, 't2_add_book.html')
        if len(request.POST['time'])>1:
            ex_price=int(request.POST['time'])
        models.message.objects.create(name=request.POST['name'],
                                  money=money,
                                  time=ex_price)
    # return render(request, 'new_car.html', {'li': mess_list_obj})
    return render(request,'t2_add_book.html')

def del_book(request):
    id=request.GET.get('id')
    del_bk=models.message.objects.get(id=int(id))
    del_bk.delete()
    return HttpResponseRedirect('/new_car.html/')

def edit_book(request):
    # id = request.GET.get('id')
    if request.method == "GET":
        id=request.GET.get('id')
        edit_bk = models.message.objects.get(id=int(id))
        print(edit_bk)
        return render(request, 't3_edit_book.html',{'result':edit_bk})
    else:
        print("fuck")
        id = request.GET.get('id')
        edit_bk = models.message.objects.get(id=int(id))
        edit_bk.name= request.POST['name']
        # edit_bk.money = request.POST['money']
        edit_bk.time = request.POST['time']
        return HttpResponseRedirect('/new_car.html/')